﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using pessoa; // Incluir o namespace pessoa
using recurso; // Incluir o namespace recurso

namespace DS_aula5__herança
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //instanciar objetos
            PessoaFisica pessoaFisica = new PessoaFisica();
            PessoaJuridica pessoaJuridica = new PessoaJuridica();

            Console.WriteLine(pessoaFisica.DefinirNome("Ana"));
            pessoaFisica.Altura = 1.72;

            Console.WriteLine(pessoaJuridica.DefinirNome("Sofa Nina Mania Ltda"));
            pessoaJuridica.NomeFantasia = "Sofa";

            // Objeto pessoa fisíca que utiliza os recursos da interface
            IRecursos iPessoaFisica = new PessoaFisica();

            Console.WriteLine(iPessoaFisica.Falar("Aulinha boa"));
        }
    }
}
