﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace recurso
{
    // Interface adiciona recursos a aplicação, implementa funcionalidades
    // Uma interface é um "contrato" com a aplicação
    interface IRecursos
    {
        // Definir o contrato
        string Falar(string falar);
        void Parar();
        string Andar();

    }
}
