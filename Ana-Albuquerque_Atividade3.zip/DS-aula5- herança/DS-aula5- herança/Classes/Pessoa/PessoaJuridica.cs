﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pessoa
{
    class PessoaJuridica : Pessoa
    {
            //atributos
            public long CNPJ { get; set; }
            public long IE { get; set; }
            public string NomeFantasia { get; set; }

        // método que sobrescreve o método da classe Pai
        public override string DefinirNome(string Nome)
        {
            this.Nome = Nome;
            return $"O nome da empresa é: {Nome}";
        }

    }

}
